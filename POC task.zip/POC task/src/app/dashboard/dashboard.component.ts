import { Component, OnInit, ViewChild } from '@angular/core';
import 'anychart';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @ViewChild('line', { static: false }) line;
  @ViewChild('pie', { static: false }) pie;
  @ViewChild('bar', { static: false }) bar;
  @ViewChild('heat', { static: false }) heat;

  linechart: any;
  piechart: any;
  barchat: any;
  heatchart: any;

  constructor() { }

  ngAfterViewInit() {
    this.getlinechart();
    this.getpiechart();
    this.getbarchart();
    this.getheatchart();
  }

  getlinechart() {
    var dataSet = anychart.data.set(this.getlineData());

    var firstSeriesData = dataSet.mapAs({ x: 0, value: 1 });

    var secondSeriesData = dataSet.mapAs({ x: 0, value: 2 });

    var thirdSeriesData = dataSet.mapAs({ x: 0, value: 3 });

    this.linechart = anychart.line();
    var first = this.linechart.line(firstSeriesData);
    var second = this.linechart.line(secondSeriesData);
    var third = this.linechart.line(thirdSeriesData);
    first.hovered().markers()
      .enabled(true)
      .type('circle')
      .size(4);
    first.tooltip()
      .position('right')
      .anchor('left-center')
      .offsetX(5)
      .offsetY(5);
    this.loadlineGraph();
  }


  loadlineGraph() {
    this.linechart.container(this.line.nativeElement);
    this.linechart.draw();
  }

  getlineData() {
    return [
      ['jan', 130000.5, 120000.1, 10000.2, 140000.0],
      ['feb', 140000.8, 130000.5, 50000.4, 120000.5],
      ['mar', 160000.6, 150000.1, 60000.3, 100000.8],
      ['apr', 180000.1, 170000.9, 80000.9, 80000.9],
      ['may', 170000.0, 180000.9, 100000.1, 80000.0],
      ['jun', 160000.6, 200000.3, 110000.5, 60000.2],
      ['jul', 140000.1, 200000.7, 120000.2, 50000.1],
      ['aug', 150000.7, 210000.6, 100000, 30000.7],
      ['sep', 120000.0, 220000.5, 80000.9, 10000.5]
    ];
  }

  getpiechart() {
    this.piechart = anychart.pie(this.getpieData());
    this.piechart.container(this.pie.nativeElement)
    this.piechart.draw();

  }

  getpieData() {
    return [['Amazon', 1222],
    ['Flipkart', 2431],
    ['Alibaba', 3624],
    ];
  }

  getbardata() {
    return [
      ['Alibaba', '48'],
      ['Amazon', '32'],
      ['Flipkart', '28'],
    ]
  }

  getbarchart() {
    this.barchat = anychart.bar(this.getbardata());
    this.barchat.container(this.bar.nativeElement);
    this.barchat.draw();
  }

  //Heat Map Integration
  getheatdata() {
    return [
      { x: "Banguluru", y: "Alibaba", heat: 15 },
      { x: "Hyderabad", y: "Alibaba", heat: 17 },
      { x: "Chennai", y: "Alibaba", heat: 21 },
      { x: "Banguluru", y: "Amazon", heat: 34 },
      { x: "Hyderabad", y: "Amazon", heat: 33 },
      { x: "Chennai", y: "Amazon", heat: 32 },
      { x: "Banguluru", y: "Flipkart", heat: 51 },
      { x: "Hyderabad", y: "Flipkart", heat: 50 },
      { x: "Chennai", y: "Flipkart", heat: 47 }
    ]
  }

  getheatchart() {
    this.heatchart = anychart.heatMap(this.getheatdata());
    this.heatchart.container(this.heat.nativeElement);
    this.heatchart.draw();
  }

  ngOnInit() {
  }
}
